package com.hydsoft;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.util.Log;

/**
 * Desc	        ${MyApplication}
 */
public class MyApplication extends Application {

    private static Context mContext;

    private static int batteryPercent;

    private static int batteryTemperature;

    private static int batteryStatus;

    private static long batteryUsageBeginTime;

    private static int batteryVolt;

    private static boolean chargingFlag = Boolean.FALSE;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        startBroadCast();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        stopBroadCast();
    }

    public static Context getContext() {
        return mContext;
    }

    public static int getBatteryPercent() {
        return batteryPercent;
    }

    public static int getBatteryTemperature() {
        return batteryTemperature;
    }

    public static int getBatteryStatus() {
        return batteryStatus;
    }

    public static long getBatteryUsageBeginTime() {
        return batteryUsageBeginTime;
    }

    public static int getBatteryVolt() {
        return batteryVolt;
    }

    private void startBroadCast() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(mBroadcastReceiver, filter);
    }

    private void stopBroadCast() {
        unregisterReceiver(mBroadcastReceiver);
    }

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (null == intent) {
                return;
            }

            String action = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                batteryPercent = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
                batteryTemperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                batteryStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN);
                if ((batteryStatus == BatteryManager.BATTERY_STATUS_NOT_CHARGING
                    || batteryStatus == BatteryManager.BATTERY_STATUS_DISCHARGING) && !chargingFlag) {
                    batteryUsageBeginTime = System.currentTimeMillis();
                    chargingFlag = Boolean.TRUE;
                } else if (batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING && chargingFlag) {
                    batteryUsageBeginTime = 0L;
                    chargingFlag = Boolean.FALSE;
                }
                batteryVolt = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                /*int plugged = intent.getIntExtra(EXTRA_PLUGGED, BATTERY_PLUGGED_ANY);
                int scale = intent.getIntExtra(EXTRA_SCALE, 0);
                int health = intent.getIntExtra(EXTRA_HEALTH, BATTERY_HEALTH_UNKNOWN);
                int maxChargingMicroAmp = intent.getIntExtra(EXTRA_MAX_CHARGING_CURRENT, -1);
                int maxChargingMicroVolt = intent.getIntExtra(EXTRA_MAX_CHARGING_VOLTAGE, -1);
                */
                //String batteryTechnologyDescript = intent.getStringExtra(EXTRA_TECHNOLOGY);
                //final int maxChargingMicroWatt;
                /*if (maxChargingMicroVolt <= 0) {
                    maxChargingMicroVolt = DEFAULT_CHARGING_VOLTAGE_MICRO_VOLT;
                }
                if (maxChargingMicroAmp > 0) {
                    // Calculating muW = muA * muV / (10^6 mu^2 / mu); splitting up the divisor
                    // to maintain precision equally on both factors.
                    maxChargingMicroWatt = (maxChargingMicroAmp / 1000)
                            * (maxChargingMicroVolt / 1000);
                } else {
                    maxChargingMicroWatt = -1;
                }*/
                /*String healthStr = getHealth(health);
                String pluggedStr = getPlugged(plugged);
                String scaleStr = getLevel(scale);*/
                /*
                String maxChargingMicroAmpStr = getMaxChargingMicroAmp(maxChargingMicroAmp);
                String maxChargingMicroVoltStr = getMaxChargingMicroVolt(maxChargingMicroVolt);
                int currentChargingCurrent = getCurrentChargingCurrent();
                String currentChargingCurrentStr = getCurrentChargingCurrentStr(currentChargingCurrent);
                int currentChargingVoltage = getCurrentChargingVoltage();
                String currentChargingVoltageStr = getCurrentChargingVoltageStr(currentChargingVoltage);*/
                /*result = MainActivity.this.getString(R.string.adb_shell_help)
                        + "\n" + MainActivity.this.getString(R.string.battery_current_level) + levelStr
                        + "\n" + MainActivity.this.getString(R.string.battery_current_temperature) + temperatureStr
                        + "\n" + MainActivity.this.getString(R.string.battery_current_volt) + batteryVoltStr
                        + "\n" + MainActivity.this.getString(R.string.battery_current_charging_current) + currentChargingCurrentStr
                        + "\n" + MainActivity.this.getString(R.string.battery_current_charging_voltage) + currentChargingVoltageStr
                        + "\n" + MainActivity.this.getString(R.string.battery_status_titls) + statusStr
                        + "\n" + MainActivity.this.getString(R.string.battery_plugged_titls) + pluggedStr
                        + "\n" + MainActivity.this.getString(R.string.battery_max_charging_current) + maxChargingMicroAmpStr
                        + "\n" + MainActivity.this.getString(R.string.battery_max_charging_voltage) + maxChargingMicroVoltStr
                        + "\n" + MainActivity.this.getString(R.string.battery_health_titls) + healthStr
                        + "\n" + MainActivity.this.getString(R.string.battery_max_level) + scaleStr
                        + "\n" + MainActivity.this.getString(R.string.battery_technology_describing) + batteryTechnologyDescript
                        +"\n充电速度 = " + maxChargingMicroWatt;*/
            }
        }

    };



}
