package com.hydsoft;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hydsoft.utils.ConstantUtil;
import com.hydsoft.utils.DeviceInfoUtils;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class MyMqttService extends Service {
    private final String TAG = MyMqttService.class.getSimpleName();
    private MqttAndroidClient  mqttAndroidClient;
    private MqttConnectOptions mqttConnectOptions;
    public String serverUri = "";//服务器地址（协议+地址+端口号）
    public String userName = "admin";//用户名
    public String password = "public";//密码
    public static Integer QOS = 1;
    public String clientId = "AndroidDevice";
    private PowerManager.WakeLock wakeLock;
    private final Intent mIntent = new Intent();
    public static final String ACTION_NAME = "com.hydsoft.MQTT_DATA_ACTION";
    private Map<String, Object> data = new HashMap<String, Object>();

    @Override
    public void onCreate() {
        super.onCreate();
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, MyMqttService.class.getName());
        wakeLock.acquire();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 从Activity中获取数据
        data = (Map<String, Object>) intent.getBundleExtra("data").getSerializable("data");
        serverUri = "tcp://" + data.get("mqttUrl");
        userName = String.valueOf(data.get("mqttUserName"));
        password = String.valueOf(data.get("mqttPwd"));
        mIntent.setAction(ACTION_NAME);
        init();
//        return super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * 发布 （模拟其他客户端发布消息）
     *
     * @param message 消息
     */
    public void publish(String topic, String message, int qos, boolean retained) {
        try {
            //参数分别为：主题、消息的字节数组、服务质量、是否在服务器保留断开连接后的最后一条消息
            mqttAndroidClient.publish(topic, message.getBytes(), qos, retained);
            data.put("historyText", "Reply Published!");
            data.put("historyCause", null);
            sendDataToActivity(data);
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "publish出现异常!", e);
        }
    }

    /**
     * 响应
     *
     * @param topic 主题
     * @param message 消息
     */
    public void response(String topic, String message) {
        Boolean retained = false;
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.serializeNulls();
        Gson gson = gsonBuilder.create();
        try {
            if (topic != null && !"".equals(topic)) {
                if (ConstantUtil.ANDROID_SUBSCRIBE_TOPIC_DEVICEINFO_GET.equals(topic)) {
                    DeviceInfo deviceInfo = new DeviceInfo();
                    deviceInfo.setDeviceName(DeviceInfoUtils.getDeviceBrand() + " "
                            + DeviceInfoUtils.getDeviceModel() + "(" + DeviceInfoUtils.getDeviceAndroidId() + ")");
                    deviceInfo.setDeviceStatus(mqttAndroidClient.isConnected() == true ? "online" : "offline");
                    deviceInfo.setDeviceBootedDate(DeviceInfoUtils.getDeviceBootedDate());
                    deviceInfo.setDeviceUptime(DeviceInfoUtils.getDeviceUptime());
                    deviceInfo.setBatteryRemainingCapacity(DeviceInfoUtils.getDeviceBatteryPercent());
                    deviceInfo.setBatteryTemperature(DeviceInfoUtils.getDeviceBatteryTemperature());
                    deviceInfo.setBatteryStatus(DeviceInfoUtils.getDeviceBatteryStatus());
                    deviceInfo.setBatteryUsageTime(DeviceInfoUtils.getDeviceBatteryUsageTime());
                    deviceInfo.setDeviceUsageCount(DeviceInfoUtils.getDeviceUsageCount(MyApplication.getContext()));
                    deviceInfo.setDeviceUsageRate(DeviceInfoUtils.getDeviceUsageRate());
                    // 设备闲置率=1-使用率
                    deviceInfo.setDeviceFreeRate(String.valueOf(1 - Double.valueOf(deviceInfo.getDeviceUsageRate())));
                    deviceInfo.setDeviceEnergyEfficiency(DeviceInfoUtils.getDeviceEnergyEfficiency());
                    deviceInfo.setCurrentRecordTime(new Date());

                    String jsonString = gson.toJson(ResponseResult.success(deviceInfo));
                    publish(ConstantUtil.ANDROID_REPLY_TOPIC_DEVICEINFO_GET, jsonString, QOS.intValue(), retained.booleanValue());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "response出现异常!", e);
        }
    }

    /**
     * 初始化
     */
    private void init() {
        clientId =  clientId + System.currentTimeMillis();
        mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), serverUri, clientId);
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectionLost(Throwable cause) {
                data.put("historyText", "The Connection was lost.");
                data.put("historyCause", cause);
                sendDataToActivity(data);
            }
            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                String messageStr = new String(message.getPayload());
                String text = "Incoming topic: " + topic + ", Incoming message: " + messageStr;
                data.put("historyText", text);
                data.put("historyCause", null);
                sendDataToActivity(data);
                response(topic, messageStr);
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                if (reconnect) {
                    String text = "Reconnected to : " + serverURI;
                    data.put("historyText", text);
                    data.put("historyCause", null);
                    sendDataToActivity(data);
                    // Because Clean Session is true, we need to re-subscribe
                    subscribeToTopic();
                } else {
                    String text = "Connected to: " + serverURI;
                    data.put("historyText", text);
                    data.put("historyCause", null);
                    sendDataToActivity(data);
                }
            }
        });
        mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setCleanSession(true); //设置是否清除缓存
        mqttConnectOptions.setConnectionTimeout(10); //设置超时时间，单位：秒
        mqttConnectOptions.setKeepAliveInterval(30); //设置心跳包发送间隔，单位：秒
        mqttConnectOptions.setUserName(userName); //设置用户名
        mqttConnectOptions.setPassword(password.toCharArray()); //设置密码

        // last will message
       /* boolean doConnect = true;
        String message = "{\"terminal_uid\":\"" + clientId + "\", \"status\":\"Offline\"}";
        String topic = ConstantUtil.ANDROID_WILL_TOPIC;
        Boolean retained = false;
        if ((!message.equals("")) || (!topic.equals(""))) {
            // 最后的遗嘱
            try {
                mqttConnectOptions.setWill(topic, message.getBytes(), QOS.intValue(), retained.booleanValue());
            } catch (Exception e) {
                Log.i(TAG, "Exception Occured", e);
                doConnect = false;
                iMqttActionListener.onFailure(null, e);
            }
        }
        if (doConnect) {
            doClientConnection();
        }*/

        try {
            mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                    disconnectedBufferOptions.setBufferEnabled(true);
                    disconnectedBufferOptions.setBufferSize(100);
                    disconnectedBufferOptions.setPersistBuffer(false);
                    disconnectedBufferOptions.setDeleteOldestMessages(false);
                    mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
                    subscribeToTopic();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    String text = "Failed to connect to: " + serverUri;
                    data.put("historyText", text);
                    data.put("historyCause", exception);
                    data.put("connectionState", "failure");
                    sendDataToActivity(data);
                }
            });
        } catch (MqttException ex){
            ex.printStackTrace();
            Log.e(TAG, "mqttAndroidClient connect error", ex);
        }

    }

    /**
     * 连接MQTT服务器
     */
//    private void doClientConnection() {
//        if (!mqttAndroidClient.isConnected() && isConnectIsNomarl()) {
//            try {
//                mqttAndroidClient.connect(mqttConnectOptions, null, iMqttActionListener);
//            } catch (MqttException e) {
//                e.printStackTrace();
//            }
//        }
//    }

    /**
     * 判断网络是否连接
     */
//    private boolean isConnectIsNomarl() {
//        ConnectivityManager connectivityManager = (ConnectivityManager) this.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
//        if (info != null && info.isAvailable()) {
//            String name = info.getTypeName();
//            Log.i(TAG, "当前网络名称：" + name);
//            return true;
//        } else {
//            Log.i(TAG, "没有可用网络");
//            /*没有可用网络的时候，延迟3秒再尝试重连*/
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    doClientConnection();
//                }
//            }, 3000);
//            return false;
//        }
//    }

    //MQTT是否连接成功的监听
//    private IMqttActionListener iMqttActionListener = new IMqttActionListener() {
//
//        @Override
//        public void onSuccess(IMqttToken arg0) {
//            Log.i(TAG, "连接成功 ");
//            try {
//                mqttAndroidClient.subscribe(ConstantUtil.ANDROID_SUBSCRIBE_TOPIC, QOS.intValue());//订阅主题，参数：主题、服务质量
//            } catch (MqttException e) {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        public void onFailure(IMqttToken arg0, Throwable arg1) {
//            arg1.printStackTrace();
//            Log.i(TAG, "连接失败 ");
//            try {
//                Thread.sleep(5000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            doClientConnection();//连接失败，重连（可关闭服务器进行模拟）
//        }
//    };


    @Override
    public void onDestroy() {
        if (wakeLock != null) {
            wakeLock.release();
            wakeLock = null;
        }
        try {
            if (mqttAndroidClient != null) {
                mqttAndroidClient.disconnect(); //断开连接
            }
        } catch (MqttException e) {
            e.printStackTrace();
            Log.e(TAG, "mqttAndroidClient.disconnect()出现异常!", e);
        }
        super.onDestroy();
    }

    public void subscribeToTopic(){
        try {
            mqttAndroidClient.subscribe(ConstantUtil.ANDROID_SUBSCRIBE_TOPIC, QOS.intValue(), null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    data.put("historyText", "Subscribed!");
                    data.put("historyCause", null);
                    sendDataToActivity(data);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    data.put("historyText", "Failed to subscribe!");
                    data.put("historyCause", exception);
                    sendDataToActivity(data);
                }
            });
        } catch (MqttException ex){
            ex.printStackTrace();
            Log.e(TAG, "Exception whilst subscribing", ex);
        }
    }

    private void sendDataToActivity(Map<String, Object> dataMap) {
        Bundle bundle = new Bundle();
        bundle.putSerializable("data", (Serializable) dataMap);
        mIntent.putExtra("data", bundle);
        sendBroadcast(mIntent);
    }
}
