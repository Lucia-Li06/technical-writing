package com.hydsoft;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.hydsoft.utils.DeviceInfoUtils;
import com.hydsoft.utils.DialogHelper;
import com.hydsoft.utils.PermissionConstants;
import com.hydsoft.utils.PermissionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private String TAG = this.getClass().getSimpleName();
    private Intent mIntent;

    private TextView tvAndroidIdLabel;
    private EditText etMqttUrl;
    private EditText etMqttUserName;
    private EditText etMqttPwd;
    private Button btnSubmit;
    private MyReceiver myReceiver;
    private Map<String, Object> data = new HashMap<String, Object>();
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor sharedPreferencesEditor;

    private HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvAndroidIdLabel = findViewById(R.id.tv_androidIdLabel);
        tvAndroidIdLabel.setText(tvAndroidIdLabel.getText() + DeviceInfoUtils.getDeviceAndroidId());
        etMqttUrl = findViewById(R.id.et_mqttUrl);
        etMqttUserName = findViewById(R.id.et_mqttUserName);
        etMqttPwd = findViewById(R.id.et_mqttPwd);
        btnSubmit = findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(this);
        sharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
        sharedPreferencesEditor = sharedPreferences.edit();
        etMqttUrl.setText(sharedPreferences.getString("mqttUrl", ""));
        etMqttUserName.setText(sharedPreferences.getString("mqttUserName", ""));
        etMqttPwd.setText(sharedPreferences.getString("mqttPwd", ""));

        mIntent = new Intent(MainActivity.this, MyMqttService.class);
        myReceiver = new MyReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MyMqttService.ACTION_NAME);
        //注册广播
        registerReceiver(myReceiver, intentFilter);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_clearHistory);
        fab.setOnClickListener(this);
        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.history_recycler_view);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        adapter = new HistoryAdapter(new ArrayList<String>());
        mRecyclerView.setAdapter(adapter);

    }

    private void addToHistory(String mainText, Throwable cause){
        if (cause != null) {
            Log.e(TAG, mainText, cause);
            mainText += " Cause: " + cause;
        } else {
            Log.i(TAG, mainText);
        }
        adapter.add(mainText);
        Snackbar.make(findViewById(android.R.id.content), mainText, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        return super.onOptionsItemSelected(item);
    }

    /**
     * 申请权限
     */
    public void requestPermission() {
        PermissionUtils.permission(PermissionConstants.PHONE)
                .rationale(new PermissionUtils.OnRationaleListener() {
                    @Override
                    public void rationale(final ShouldRequest shouldRequest) {
                        Log.d(TAG, "onDenied: 权限被拒绝后弹框提示");
                        DialogHelper.showRationaleDialog(shouldRequest, MainActivity.this);
                    }
                })
                .callback(new PermissionUtils.FullCallback() {
                    @Override
                    public void onGranted(List<String> permissionsGranted) {
                        //向Service传递data
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("data", (Serializable) data);
                        mIntent.putExtra("data", bundle);
                        //开启服务
                        startService(mIntent);
                    }

                    @Override
                    public void onDenied(List<String> permissionsDeniedForever,
                                         List<String> permissionsDenied) {
                        Log.d(TAG, "onDenied: 权限被拒绝");
                        if (!permissionsDeniedForever.isEmpty()) {
                            DialogHelper.showOpenAppSettingDialog(MainActivity.this);
                        }
                    }
                })
                .request();
    }

    @Override
    protected void onDestroy() {
        //停止服务
        stopService(mIntent);
        unregisterReceiver(myReceiver);
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_submit:
                String mqttUrl = etMqttUrl.getText().toString();
                String mqttUserName = etMqttUserName.getText().toString();
                String mqttPwd = etMqttPwd.getText().toString();
                if (mqttUrl != null && !"".equals(mqttUrl)) {
                    btnSubmit.setEnabled(false);
                    data.put("mqttUrl", mqttUrl);
                    data.put("mqttUserName", mqttUserName);
                    data.put("mqttPwd", mqttPwd);
                    sharedPreferencesEditor.putString("mqttUrl", mqttUrl);
                    sharedPreferencesEditor.putString("mqttUserName", mqttUserName);
                    sharedPreferencesEditor.putString("mqttPwd", mqttPwd);
                    sharedPreferencesEditor.apply();
                    requestPermission();
                    Toast.makeText(this, "正在连接...", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "MQTT URL 不能为空!", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.fab_clearHistory:
                adapter.clearAll();
                break;
            default:
                break;
        }
    }

    class MyReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, final Intent intent) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //获取从Service中传来的data
                    data = (Map<String, Object>) intent.getBundleExtra("data").getSerializable("data");
                    //更新UI
                    if (data != null) {
                        addToHistory(String.valueOf(data.get("historyText")), (Throwable) data.get("historyCause"));
                        if ("failure".equalsIgnoreCase(String.valueOf(data.get("connectionState")))) {
                            btnSubmit.setEnabled(true);
                        }
                    }
                }
            });
        }
    }
}