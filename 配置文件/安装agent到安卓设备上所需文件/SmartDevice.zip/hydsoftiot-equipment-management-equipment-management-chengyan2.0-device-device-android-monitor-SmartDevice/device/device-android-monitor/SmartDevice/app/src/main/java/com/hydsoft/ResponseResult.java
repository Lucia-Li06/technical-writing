package com.hydsoft;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.HashMap;

public class ResponseResult<T> {
    // meta数据结构
    private HashMap<String, Object> meta = new HashMap<String, Object>();
    // Android端响应的响应体
    private T data;

    public ResponseResult() {
        meta.put("success", Boolean.FALSE);
        meta.put("message", "Failure");
    }

    public ResponseResult(HashMap<String, Object> meta, T data) {
        this.meta = meta;
        this.data = data;
    }

    public HashMap<String, Object> getMeta() {
        return meta;
    }

    public void setMeta(HashMap<String, Object> meta) {
        this.meta = meta;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseResult{" +
                "meta=" + meta +
                ", data=" + data +
                '}';
    }

    public static <T> ResponseResult<T> success() {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("success", Boolean.TRUE);
        map.put("message", "Success");
        return new ResponseResult<T>(map, null);
    }

    public static <T> ResponseResult<T> success(T data) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("success", Boolean.TRUE);
        map.put("message", "Success");
        return new ResponseResult<T>(map, data);
    }

    public static <T> ResponseResult<T> success(String message, T data) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("success", Boolean.TRUE);
        map.put("message", message);
        return new ResponseResult<T>(map, data);
    }

    public static <T> ResponseResult<T> fail() {
        return new ResponseResult<T>();
    }

    public static <T> ResponseResult<T> fail(T data) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("success", Boolean.FALSE);
        map.put("message", "Failure");
        return new ResponseResult<T>(map, data);
    }

    public static <T> ResponseResult<T> fail(String message, T data) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("success", Boolean.FALSE);
        map.put("message", message);
        return new ResponseResult<T>(map, data);
    }

    public static void main(String[] args) {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.serializeNulls();
        Gson gson = gsonBuilder.create();
        String jsonString1=gson.toJson(ResponseResult.success());
        String jsonString2=gson.toJson(ResponseResult.success("haha"));
        String jsonString3=gson.toJson(ResponseResult.success("成功!", "haha"));
        String jsonString4=gson.toJson(ResponseResult.fail());
        String jsonString5=gson.toJson(ResponseResult.fail("heihei"));
        String jsonString6=gson.toJson(ResponseResult.fail("失败!", "heihei"));
        System.out.println(jsonString1);
        System.out.println(jsonString2);
        System.out.println(jsonString3);
        System.out.println(jsonString4);
        System.out.println(jsonString5);
        System.out.println(jsonString6);

        System.out.println(String.valueOf(1 - Double.valueOf("0.04")));
    }
}
